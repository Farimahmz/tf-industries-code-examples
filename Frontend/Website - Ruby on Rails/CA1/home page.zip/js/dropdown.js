function jsFunction(url) {
 window.open(url, '_blank');
}